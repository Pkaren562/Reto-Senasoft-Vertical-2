<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>REGISTRAR</title>
  </head>
  <body>
          <br>
          
        <!-- inicio contenedor inicial  !-->
        <div class="container border"  style="background-color:#E1F5FE">
            <div class="row">
              <div class="col-md-1">
              </div>
                <div class="col-md-2">
                  <img src="Img/logosena.png">
                </div>
                <div class="col-md-1">
                </div>
                <div class="col-md-8">
                  <p class="text-center"><h1>Sistema de registro Sena</h1></p>
                </div>
            </div>
             <br>
        </div>
        <!-- cierre contenedor inicial  !-->



        <!-- inicio contenedor menu  !-->
        <div class="container border"  style="background-color:#FCF3CF">
          <?php
          /* MENU */
          include "menuu.php";
          ?>
        </div>
        <!-- cierre contenedor menu  !-->



         <!-- inicio contenedor azul  !-->
          <div class="container border"  style="background-color:#E1F5FE">
           <br>
           <br>
           <!--Inicio de cards-->
           <div class="row">
                    <div v class="col-md-2">
                               <div class="card">
                                    <img src="Img/id.jpg" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">Repositorio</h5>
                                    <p class="card-text">Do de identificacion</p>
                                    <a href="repoiden.php" class="btn btn-primary">Ver archivos</a>
                                </div>
                            </div>
                    </div>
                    <div class="col-md-2">
                              <div class="card" >
                                        <img src="Img/per.jfif" class="card-img-top" alt="...">
                                      <div class="card-body">
                                         <h5 class="card-title">Repositorio</h5>
                                         <p class="card-text">Permisos de salida</p>
                                          <a href="pers.php" class="btn btn-primary">Ver archivos</a>
                                      </div>
                                </div>
                      </div>
                      <div class="col-md-2">
                                <div class="card" >
                                        <img src="Img/fac.jpg" class="card-img-top" alt="...">
                                      <div class="card-body">
                                         <h5 class="card-title">Repositorio</h5>
                                         <p class="card-text">Facturas</p>
                                          <a href="fact.php" class="btn btn-primary">Ver archivos</a>
                                      </div>
                                </div>
                      </div>
                      <div class="col-md-2">
                                <div class="card" >
                                        <img src="Img/cur.jpg" class="card-img-top" alt="...">
                                      <div class="card-body">
                                         <h5 class="card-title">Repositorio</h5>
                                         <p class="card-text">Cuentas de cobro</p>
                                          <a href="cuen.php" class="btn btn-primary">Ver archivos</a>
                                      </div>
                                </div>
                      </div>
                      <div class="col-md-2">
                                <div class="card" >
                                        <img src="Img/cor.png" class="card-img-top" alt="...">
                                      <div class="card-body">
                                         <h5 class="card-title">Repositorio</h5>
                                         <p class="card-text">Cotizaciones</p>
                                          <a href="coti.php" class="btn btn-primary">Ver archivos</a>
                                      </div>
                                </div>
                      </div>
                      <div class="col-md-2">
                                <div class="card" >
                                        <img src="Img/i.jpg" class="card-img-top" alt="...">
                                      <div class="card-body">
                                         <h5 class="card-title">Repositorio</h5>
                                         <p class="card-text">Contratos</p>
                                          <a href="contratos.php" class="btn btn-primary">Ver archivos</a>
                                      </div>
                                </div>
                      </div>
  </div>
  <br>
  <br>
  <br>
  <br>
  <!--Cierre de cards-->
           <div class="row">
        <!-- cierre contenedor azul  !-->




         <!-- inicio contenedor footer  !-->
          <div class="container border"  style="background-color:#FCF3CF">
                <?php
                /*FOOTER */
                include "Footer.php";
                ?>
          </div>
        <!-- cierre contenedor footer  !-->



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
    
  </body>
</html>