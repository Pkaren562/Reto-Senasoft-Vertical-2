<!-- Abrir menu -->
<nav class="navbar navbar-expand-lg" backgrom-color:"#FCF3CF">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-dark" aria-current="page" href="Index.php" >Inicio</a>
        </li>
        <li class="nav-item"></li>
          <a class="nav-link active text-dark" aria-current="page" href="registrar.php" >Registrar</a>
        </li>
        <li class="nav-item"></li>
          <a class="nav-link active text-dark" aria-current="page" href="ingresar.php" >Ingresar</a>
        </li>
        <li class="nav-item"></li>
          <a class="nav-link active text-dark" aria-current="page" href="Archivos.php" >Subir archivos</a>
        </li>
        <li class="nav-item"></li>
          <a class="nav-link active text-dark" aria-current="page" href="repositorios.php" >Repositorios</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Buscar..." aria-label="Search">
        <button type="button" class="btn btn-outline-dark">Buscar</button>
      </form>
    </div>
  </div>
</nav>
<!-- Cerrar menu-->