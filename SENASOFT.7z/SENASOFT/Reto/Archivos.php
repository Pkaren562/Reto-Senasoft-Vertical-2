<!doctype html>
<html lang="en">
  <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <title>REGISTRAR</title>
  </head>
  <body>
                <br>
                <!-- inicio contenedor inicial  !-->
                <div class="container border"  style="background-color:#E1F5FE">
                    <div class="row">
                        <div class="col-md-1">
                        </div>
                        <div class="col-md-2">
                          <img src="Img/logosena.png">
                        </div>
                        <div class="col-md-1">
                        </div>
                        <div class="col-md-8">
                           <p class="text-center"><h1>Sistema de registro Sena</h1></p>
                        </div>
                    </div>
                    <br>
                </div>
                <!-- cierre contenedor inicial  !-->


                <!-- inicio contenedor menu !-->
                    <div class="container border"  style="background-color:#FCF3CF">
                        <?php
                        /* MENU */
                        include "menuu.php";
                        ?>
                    </div>
                    <!-- cierre contenedor menu !-->


                <!-- inicio contenedor azul !-->
                    <div class="container border"  style="background-color:#E1F5FE">
                    <br>
                    <br>
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-3">
                        </div>
                        <!-- inicio contenedor ingreso archivo  !-->
                            <div class="col-md-6">
                                    <div class="container-sm border " style="background-color:#D4EFDF">
                                        <form action="in.php" method="POST">
                                            <br>
                                            <h4><center>Ingresar Archivo</center></h4>
                                            <div class="mb-3">
                                                    <label for="formGroupExampleInput" class="form-label">Nombre del archivo</label>
                                                    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="">
                                                  </div>
                                                  
                                                  <label>Extension del archivo</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected> Seleccionar</option>
                                                <option value="1"> PDF</option>
                                                <option value="2"> JPG </option>
                                                <option value="3"> PNG </option>
                                                <option value="4"> DOCX </option>
                                                <option value="5"> DOT </option>
                                                <option value="6"> XLSX </option>
                                            </select>
                                            <br>

                                            <label>Tipo de Archivo</label>
                                            <select class="form-select" aria-label="Default select example">
                                                <option selected> Seleccionar</option>
                                                <option value="1"> Documento de Identificacion</option>
                                                <option value="2"> Facturas </option>
                                                <option value="3"> Cuentas de cobro </option>
                                                <option value="4"> Cotizaciones </option>
                                                <option value="5"> Contrato </option>
                                                <option value="6"> Permisos de salida </option>
                                            </select>
                                            <br>
                                            <form action="../../form-result.php" method="post" enctype="multipart/form-data" target="_blank">
                                            <p> Sube un archivo:
                                              <input type="file" name="archivosubido">
                                            </p>
                                            </form>
                                            <br>
                                            
                                            <!-- boton modal -->
                                                <center><button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                Enviar
                                                </button></center>
                                                <br>

                                                <!-- inicio Modal -->
                                                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel"></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p><center>5seg...</center></p>
                                                        <center> <img src="Img/cargando.png" width="100px" height="100px"> </center>
                                                        <br>
                                                        <center>Su archivo se guardo con exito en el repositorio </center>
                                                        
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Aceptar</button>
                                                    </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <!-- final Modal -->
                                            <br>
                                         </form>
                                       </div>
                                            <br>
                                            <br>

                                </div>
                                    <div class="col-md-3">
                                    </div>
                                     <!-- cierre contenedor ingreso archivo !-->

                        </div>
                    </div>
                    <!-- cierre contenedor azul !-->



                    <!-- inicio contenedor footer  !-->
                    <div class="container border"  style="background-color:#FCF3CF">
                            <?php
                            /*FOOTER */
                            include "Footer.php";
                            ?>
                    </div>
                    <!-- inicio contenedor footer  !-->




                        <!-- Optional JavaScript; choose one of the two! -->

                        <!-- Option 1: Bootstrap Bundle with Popper -->
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

                        <!-- Option 2: Separate Popper and Bootstrap JS -->
                        <!--
                        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
                        -->
    
  </body>
</html>