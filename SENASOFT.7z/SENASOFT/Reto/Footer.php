<!-- Abrir Footer -->

<footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="Index.php" class="nav-link px-2 text-muted">Inicio</a></li>
      <li class="nav-item"><a href="registrar.php" class="nav-link px-2 text-muted">Registrar</a></li>
      <li class="nav-item"><a href="ingresar.php" class="nav-link px-2 text-muted">Ingresar</a></li>
      <li class="nav-item"><a href="Archivos.php" class="nav-link px-2 text-muted">Subir archivos</a></li>
      <li class="nav-item"><a href="repositorios.php" class="nav-link px-2 text-muted">Repositorios</a></li>
    </ul>
    <p class="text-center text-muted">© 2021 Senasoft, Sena</p>
  </footer>

<!-- Cerrar Footer-->